<?php $__env->startSection('title', 'Server Error - Clippy'); ?>

<?php
    $code = '500';
    $title = 'Server Error - Clippy';
    $message = 'Something went wrong on our end. Our team has been notified and is working to fix this issue.';
?>

<?php echo $__env->make('errors.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/siam/Documents/Projects/Personal/clippy/resources/views/errors/500.blade.php ENDPATH**/ ?>