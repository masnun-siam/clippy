<?php $__env->startSection('title', 'Access Forbidden - Clippy'); ?>

<?php
    $code = '403';
    $title = 'Access Forbidden - Clippy';
    $message = 'You don\'t have permission to access this resource. Please check your credentials and try again.';
?>

<?php echo $__env->make('errors.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/siam/Documents/Projects/Personal/clippy/resources/views/errors/403.blade.php ENDPATH**/ ?>