<?php $__env->startSection('title', 'Service Unavailable - Clippy'); ?>

<?php
    $code = '503';
    $title = 'Service Unavailable - Clippy';
    $message = 'Clippy is temporarily down for maintenance. We\'ll be back shortly with improvements!';
?>

<?php echo $__env->make('errors.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/siam/Documents/Projects/Personal/clippy/resources/views/errors/503.blade.php ENDPATH**/ ?>