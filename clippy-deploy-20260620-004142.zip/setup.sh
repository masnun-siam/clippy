#!/bin/bash
set -e
echo "Setting up Clippy..."
cp .env.example .env
chmod -R 775 storage bootstrap/cache
php artisan key:generate
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan storage:link
php artisan migrate --force
echo "Done! Edit .env if you need to change DB creds or APP_URL."
